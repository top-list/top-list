/*
 * Copyright 2018-present, Yudong (Dom) Wang
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.dw.boot;

/** 
* @Class Name : TomcatConnectorException 
* @Description: A exception is thrown when a Tomcat connector fails to start 
* @Author     : Dom Wang 
* @Email      : witpool@outlook.com
* @Date       : Jan 28, 2018 6:24:44 PM 
* @Version    : 1.0 
*/
public class TomcatConnectorException extends TomcatContainerException
{
    private static final long serialVersionUID = 5244647422180852624L;

    private final int port;

    /**
    * 
    * @Title      : TomcatConnectorException 
    * @Description: New instance for a connector that's configured to listen on the given port. 
    * @Param      : @param port
     */
    public TomcatConnectorException(int port)
    {
        super("Connector configured to listen on port " + port + " failed to start", null);
        this.port = port;
    }

    public int getPort()
    {
        return this.port;
    }
}
