/* 
 * Copyright 2017-2018 Toplst.Net All Rights Reserved.
 * 
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
   
 *  http://www.toplst.net/licenses 
 * 
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

// API Definitions
var urlPrefix = "http://localhost:8080/api/v1/";

var postAPI = urlPrefix + "posts";

var commentAPI = urlPrefix + "comments";

var followerAPI = urlPrefix + "followers";

var histAPI = urlPrefix + "histories";

var reportAPI = urlPrefix + "reports";

var topicAPI = urlPrefix + "topics";

var userAPI = urlPrefix + "users";

var visitorAPI = urlPrefix + "visitors"

// Application
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

//app.initialize();

var isbind = 0;

// Get post list
var getPostList = function (page, size) {
    $.mobile.loading("show");
    
    $.get(postAPI + "?page=" + page + "&size=" + size, null,
        function (data) {
            $("#list").html("");
            
            var list = $("#list");
            var arr = [];
            
            $.each(data["data"], function(i, post) {
                arr.push('<li><a href="#" data-no="' 
                         + post["postID"] 
                         + '"><h2>' 
                         + post["title"] 
                         + '</h2><img src="../img/logo.png"><p>'
                         + post["descr"].substr(0,64)
                         + '...</p></a></li>'
                         );
            });

            if (arr.length > 0) {
                list.html(arr.join(""));
                list.listview("refresh");
            }

            $.mobile.loading("hide");
        });
};
var isAjax=false

// Get post detail
var getPostDetail = function () {

    $.mobile.loading("show");

    var postID = $(this).attr("data-no");
    
    if(isAjax) return;
    isAjax=true

    $.get(postAPI + "/" + postID, null,
        function (data) {
            isAjax=false
            
            var data = data["data"];
            if (!data) {
                return false;
            }
            
            $("#detail").find(".ui-content h2").html(data["title"]);
            
            var tbody = $("#detail").find(".ui-content tbody");
            tbody.html("");

            var tr = $("<tr></tr>");
            tr.html('<td>' + data["user"] + '</td>' +
                    '<td>' + data["descr"] + '</td>' +
                    '<td>' + data["postAt"] + '</td>' +
                    '<td>' + data["stat"] + '</td>' +
                    '<td>' + data["comments"] + '</td>' +
                    '<td>' + data["visitors"] + '</td>' +
                    '<td>' + data["reports"] + '</td>' +
                    '<td>' + data["topics"] + '</td>' +
                    '<td>' + data["followers"] + '</td>');
            tbody.append(tr);

            $.mobile.loading("hide");
            $.mobile.changePage("#detail");
        });

};

// bind event
var bindEvent = function () {
    $("#list").on("click", "a", getPostDetail);
};

$(document).on("pageshow", "#home", function () {
    if (isbind) return
    isbind = 1;
    bindEvent();
    getPostList(0, 2);
});

$(document).on("pageload", function(event, data){
    alert("aa");
    //getPostList();
});