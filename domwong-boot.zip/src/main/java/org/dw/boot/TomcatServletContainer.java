/*
 * Copyright 2018-present, Yudong (Dom) Wang
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.dw.boot;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.naming.NamingException;

import org.apache.catalina.Container;
import org.apache.catalina.Context;
import org.apache.catalina.Engine;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Service;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.naming.ContextBindings;

import dw.util.AssertUtils;

/** 
* @Class Name : TomcatServletContainer 
* @Description: Tomcat servlet container 
* @Author     : Dom Wang 
* @Email      : witpool@outlook.com
* @Date       : Jan 27, 2018 9:53:40 PM 
* @Version    : 1.0 
*/
public class TomcatServletContainer implements ITomcatServletContainer
{
    private static Logger log = LogManager.getLogger(TomcatServletContainer.class);

    private static final AtomicInteger counter = new AtomicInteger(-1);

    private final Map<Service, Connector[]> srvConctors = new HashMap<Service, Connector[]>();

    private final Object monitor = new Object();

    private final Tomcat tomcat;

    private final boolean autoStart;

    private volatile boolean started;

    /** 
    * @Title      : TomcatServletContainer 
    * @Description: Create a new instance 
    * @Param      : @param tomcat the underlying Tomcat server
    */
    public TomcatServletContainer(Tomcat tomcat)
    {
        this(tomcat, true);
    }

    /**
    * @Title      : TomcatServletContainer 
    * @Description: Create a new instance 
    * @Param      : @param tomcat the underlying Tomcat server
    * @Param      : @param autoStart if the server should be started
     */
    public TomcatServletContainer(Tomcat tomcat, boolean autoStart)
    {
        AssertUtils.notNull(tomcat, "Tomcat Server must not be null");
        this.tomcat = tomcat;
        this.autoStart = autoStart;
        this.init();
    }

    /**
    * 
    * @Title      : init 
    * @Description: Tomcat initialized 
    * @Param      : @throws TomcatServletContainerException 
    * @Return     : void
    * @Throws     :
     */
    private void init() throws TomcatContainerException
    {
        log.info("Tomcat initialized with port(s): " + this.getPortsDescr(false));
        synchronized (this.monitor)
        {
            this.setEngineName();
            try
            {
                // Remove service connectors
                rmSrvConnectors();

                // Start the server to trigger initialization listeners
                this.tomcat.start();

                // Check failure exception directly in the main thread
                this.checkContainerState();

                Context ctx = this.findContext();

                try
                {
                    ContextBindings.bindClassLoader(ctx,
                                    this.getNamingToken(ctx),
                                    this.getClass().getClassLoader());
                }
                catch(NamingException e)
                {
                    // Naming is not enabled. Continue
                }

                // Create a blocking non-daemon to stop immediate shutdown
                this.startAwaitThd();
            }
            catch(Exception e)
            {
                counter.decrementAndGet();
                throw new TomcatContainerException("Unable to start Tomcat", e);
            }
        }
    }

    public void start() throws TomcatContainerException
    {
        synchronized (this.monitor)
        {
            if (this.started)
            {
                return;
            }
            try
            {
                this.addPrevConnectors();
                Connector cnctr = this.tomcat.getConnector();
                if (null != cnctr && this.autoStart)
                {
                    this.startContainers();
                }
                this.checkConnectorState();
                this.started = true;
                log.info("Tomcat started on port(s): " + getPortsDescr(true));
            }
            catch(TomcatConnectorException e)
            {
                this.stopSilently();
                throw e;
            }
            catch(Exception e)
            {
                throw new TomcatContainerException("Unable to start Tomcat servlet container", e);
            } 
            finally
            {
                Context ctx = this.findContext();
                ContextBindings.unbindClassLoader(ctx, 
                                                  getNamingToken(ctx),
                                                  getClass().getClassLoader());
            }
        }
    }

    public void stop() throws TomcatContainerException
    {
        synchronized (this.monitor)
        {
            boolean wasStarted = this.started;
            try
            {
                this.started = false;
                try
                {
                    this.stopTomcat();
                    this.tomcat.destroy();
                }
                catch(LifecycleException ex)
                {
                    // swallow and continue
                }
            }
            catch(Exception ex)
            {
                throw new TomcatContainerException("Unable to stop embedded Tomcat", ex);
            } 
            finally
            {
                if (wasStarted)
                {
                    counter.decrementAndGet();
                }
            }
        }
    }

    public int getPort()
    {
        Connector cnctr = this.tomcat.getConnector();
        if (null != cnctr)
        {
            return cnctr.getLocalPort();
        }
        return 0;
    }

    /**
    * 
    * @Title      : getTomcat 
    * @Description: Returns access to the underlying Tomcat server 
    * @Param      : @return the Tomcat server
    * @Return     : Tomcat
    * @Throws     :
     */
    public Tomcat getTomcat()
    {
        return this.tomcat;
    }

    /**
    * 
    * @Title      : getSrvConnectors 
    * @Description: Get service connectors 
    * @Param      : @return 
    * @Return     : Map<Service,Connector[]>
    * @Throws     :
     */
    Map<Service, Connector[]> getSrvConnectors()
    {
        return this.srvConctors;
    }
    
    /**
    * 
    * @Title      : getPortsDescr 
    * @Description: Get port description 
    * @Param      : @param localPort
    * @Param      : @return 
    * @Return     : String
    * @Throws     :
     */
    private String getPortsDescr(boolean localPort)
    {
        StringBuilder ports = new StringBuilder();
        for (Connector conctor : this.tomcat.getService().findConnectors())
        {
            ports.append(ports.length() == 0 ? "" : " ");
            int port = (localPort ? conctor.getLocalPort() : conctor.getPort());
            ports.append(port + " (" + conctor.getScheme() + ")");
        }
        return ports.toString();
    }
    
    /**
    * 
    * @Title      : setEngineName 
    * @Description: Add container ID to engine name 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void setEngineName()
    {
        int containerId = counter.incrementAndGet();
        if (containerId <= 0)
        {
            return;
        }

        Engine engine = this.tomcat.getEngine();
        engine.setName(engine.getName() + "-" + containerId);
    }

    /**
    * 
    * @Title      : rmSrvConnectors 
    * @Description: Remove service connectors 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void rmSrvConnectors()
    {
        for (Service srv : this.tomcat.getServer().findServices())
        {
            Connector[] cnctrs = srv.findConnectors().clone();
            this.srvConctors.put(srv, cnctrs);
            for (Connector cnctr : cnctrs)
            {
                srv.removeConnector(cnctr);
            }
        }
    }
    
    /**
    * 
    * @Title      : checkContainerState 
    * @Description: Check container state 
    * @Param      : @throws Exception 
    * @Return     : void
    * @Throws     :
     */
    private void checkContainerState() throws Exception
    {
        Container[] children = this.tomcat.getHost().findChildren();
        for (Container child : children)
        {
            if (!LifecycleState.STARTED.equals(child.getState()))
            {
                throw new IllegalStateException("Failed to start " + child);
            }
        }
    }
    
    /**
    * 
    * @Title      : checkConnectorState 
    * @Description: Check connector state 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void checkConnectorState()
    {
        for (Connector cnctr : this.tomcat.getService().findConnectors())
        {
            if (LifecycleState.FAILED.equals(cnctr.getState()))
            {
                throw new TomcatConnectorException(cnctr.getPort());
            }
        }
    }
    
    /**
    * 
    * @Title      : findContext 
    * @Description: Find a context container
    * @Param      : @return a container
    * @Return     : Context 
    * @Throws     :
     */
    private Context findContext()
    {
        for (Container child : this.tomcat.getHost().findChildren())
        {
            if (child instanceof Context)
            {
                return (Context) child;
            }
        }
        throw new IllegalStateException("The host does not contain a Context");
    }

    /**
    * 
    * @Title      : getNamingToken 
    * @Description: Get a context naming token 
    * @Param      : @param ctx
    * @Param      : @return a context naming token
    * @Return     : Object
    * @Throws     :
     */
    private Object getNamingToken(Context ctx)
    {
        try
        {
            return ctx.getNamingToken();
        }
        catch(NoSuchMethodError e)
        {
            // Use the context itself on Tomcat 7
            return ctx;
        }

    }
    
    /**
    * 
    * @Title      : startAwaitThd 
    * @Description: All Tomcat threads are daemon threads.
    *             : Create a blocking non-daemon to stop immediate shutdown 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void startAwaitThd()
    {
        Thread awaitThd = new Thread("container-" + (counter.get()))
        {
            @Override
            public void run()
            {
                TomcatServletContainer.this.tomcat.getServer().await();
            }
        };
        awaitThd.setContextClassLoader(getClass().getClassLoader());
        awaitThd.setDaemon(false);
        awaitThd.start();
    }

    /**
    * 
    * @Title      : startContainers 
    * @Description: Start containers
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void startContainers()
    {
        try
        {
            for (Container child : this.tomcat.getHost().findChildren())
            {
                child.start();
            }
        }
        catch(Exception e)
        {
            log.error("Cannot start container: ", e);
            throw new TomcatContainerException("Unable to start Tomcat container", e);
        }
    }
    
    /**
    * 
    * @Title      : addPrevConnectors 
    * @Description: Add previously removed connectors 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void addPrevConnectors()
    {
        for (Service srv : this.tomcat.getServer().findServices())
        {
            Connector[] cnctrs = this.srvConctors.get(srv);
            if (null == cnctrs)
            {
                continue;
            }

            for (Connector cnctr : cnctrs)
            {
                srv.addConnector(cnctr);
                if (!this.autoStart)
                {
                    this.stopProtHandler(cnctr);
                }
            }
            this.srvConctors.remove(srv);
        }
    }

    /**
    * 
    * @Title      : stopProtHandler 
    * @Description: Stop protocol handler  
    * @Param      : @param cnctr 
    * @Return     : void
    * @Throws     :
     */
    private void stopProtHandler(Connector cnctr)
    {
        try
        {
            cnctr.getProtocolHandler().stop();
        }
        catch(Exception e)
        {
            log.error("Cannot pause connector: ", e);
        }
    }
    
    /**
    * 
    * @Title      : stopSilently 
    * @Description: Stop Tomcat silently, ignore exception
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void stopSilently()
    {
        try
        {
            this.stopTomcat();
        }
        catch(LifecycleException e)
        {
            // Ignore
        }
    }

    /**
    * 
    * @Title      : stopTomcat 
    * @Description: Stop Tomcat 
    * @Param      : @throws LifecycleException 
    * @Return     : void
    * @Throws     :
     */
    private void stopTomcat() throws LifecycleException
    {
        Thread thd = Thread.currentThread();
        this.tomcat.stop();
    }
    
}
