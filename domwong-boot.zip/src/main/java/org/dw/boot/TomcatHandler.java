/*
 * Copyright 2018-present, Yudong (Dom) Wang
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.dw.boot;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.naming.NamingException;

import org.apache.catalina.Container;
import org.apache.catalina.Context;
import org.apache.catalina.Engine;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Service;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.startup.Tomcat;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.naming.ContextBindings;

import dw.util.AssertUtils;

/** 
* @Class Name : TomcatHandler 
* @Description: Handler for tomcat container  
* @Author     : Dom Wang 
* @Email      : witpool@outlook.com
* @Date       : Jan 28, 2018 7:52:24 PM 
* @Version    : 1.0 
*/
public class TomcatHandler
{
    private static Logger log = LogManager.getLogger(TomcatHandler.class);

    private static final AtomicInteger counter = new AtomicInteger(-1);

    private static TomcatHandler handler = null;

    private final Map<Service, Connector[]> srvConnectors = new HashMap<Service, Connector[]>();

    private final Object monitor = new Object();

    private final Tomcat tomcat;

    private volatile boolean started;
    
    /** 
    * @Title      : TomcatHandler 
    * @Description: Create a new instance  
    * @Param      : @param tomcat the underlying Tomcat container
    */
    public TomcatHandler(Tomcat tomcat)
    {
        AssertUtils.notNull(tomcat, "Tomcat Server must not be null");
        this.tomcat = tomcat;
        this.init();
    }

    /**
    * 
    * @Title      : getInstance 
    * @Description: New TomcatHandler instance 
    * @Param      : @param tomcat
    * @Param      : @return 
    * @Return     : TomcatHandler
    * @Throws     :
     */
    public static TomcatHandler getInstance(Tomcat tomcat)
    {
        if (handler == null)
        {
            handler = new TomcatHandler(tomcat);
        }
        return handler;
    }
    
    /**
    * 
    * @Title      : setEngineName 
    * @Description: Add container ID to engine name 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void setEngineName()
    {
        int containerId = counter.incrementAndGet();
        if (containerId <= 0)
        {
            return;
        }

        Engine engine = this.tomcat.getEngine();
        engine.setName(engine.getName() + "-" + containerId);
    }
    
    /**
    * 
    * @Title      : getPortsDescr 
    * @Description: Get port description 
    * @Param      : @param localPort
    * @Param      : @return 
    * @Return     : String
    * @Throws     :
     */
    private String getPortsDescr(boolean localPort)
    {
        StringBuilder ports = new StringBuilder();
        for (Connector conctor : this.tomcat.getService().findConnectors())
        {
            ports.append(ports.length() == 0 ? "" : " ");
            int port = (localPort ? conctor.getLocalPort() : conctor.getPort());
            ports.append(port + " (" + conctor.getScheme() + ")");
        }
        return ports.toString();
    }

    /**
    * 
    * @Title      : rmSrvConnectors 
    * @Description: Remove service connectors 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void rmSrvConnectors()
    {
        for (Service srv : this.tomcat.getServer().findServices())
        {
            Connector[] connectors = srv.findConnectors().clone();
            this.srvConnectors.put(srv, connectors);
            for (Connector connector : connectors)
            {
                srv.removeConnector(connector);
            }
        }
    }
    
    /**
    * 
    * @Title      : checkContainersState 
    * @Description: Check containers' state 
    * @Param      : @throws Exception 
    * @Return     : void
    * @Throws     :
     */
    private void checkContainersState() throws Exception
    {
        Container[] children = this.tomcat.getHost().findChildren();
        for (Container child : children)
        {
            if (!LifecycleState.STARTED.equals(child.getState()))
            {
                throw new IllegalStateException("Failed to start " + child);
            }
        }
    }
    
    /**
    * 
    * @Title      : checkConnectorsState 
    * @Description: Check connectors' state 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void checkConnectorsState()
    {
        for (Connector connector : this.tomcat.getService().findConnectors())
        {
            if (LifecycleState.FAILED.equals(connector.getState()))
            {
                throw new TomcatConnectorException(connector.getPort());
            }
        }
    }
    
    /**
    * 
    * @Title      : findContext 
    * @Description: Find a context container
    * @Param      : @return a container
    * @Return     : Context 
    * @Throws     :
     */
    private Context findContext()
    {
        for (Container child : this.tomcat.getHost().findChildren())
        {
            if (child instanceof Context)
            {
                return (Context) child;
            }
        }
        throw new IllegalStateException("The host does not contain a Context");
    }
    
    /**
    * 
    * @Title      : getNamingToken 
    * @Description: Get a context naming token 
    * @Param      : @param ctx
    * @Param      : @return a context naming token
    * @Return     : Object
    * @Throws     :
     */
    private Object getNamingToken(Context ctx)
    {
        try
        {
            return ctx.getNamingToken();
        }
        catch(NoSuchMethodError e)
        {
            // Use the context itself on Tomcat 7
            return ctx;
        }
    }
    
    /**
    * 
    * @Title      : startAwaitThd 
    * @Description: All Tomcat threads are daemon threads.
    *             : Create a blocking non-daemon to stop immediate shutdown 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void startAwaitThd()
    {
        Thread awaitThd = new Thread("container-" + (counter.get()))
        {
            @Override
            public void run()
            {
                TomcatHandler.this.tomcat.getServer().await();
            }
        };
        awaitThd.setContextClassLoader(getClass().getClassLoader());
        awaitThd.setDaemon(true);
        awaitThd.start();
    }
    
    /**
    * 
    * @Title      : addPrevConnectors 
    * @Description: Add previously removed connectors 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void addPrevConnectors()
    {
        for (Service srv : this.tomcat.getServer().findServices())
        {
            Connector[] connectors = this.srvConnectors.get(srv);
            if (null == connectors)
            {
                continue;
            }

            for (Connector connector : connectors)
            {
                srv.addConnector(connector);
            }
            this.srvConnectors.remove(srv);
        }
    }
    
    /**
    * 
    * @Title      : startContainers 
    * @Description: Start containers
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void startContainers()
    {
        try
        {
            for (Container child : this.tomcat.getHost().findChildren())
            {
                child.start();
            }
        }
        catch(Exception e)
        {
            log.error("Cannot start container: ", e);
            throw new TomcatContainerException("Unable to start Tomcat container", e);
        }
    }
    
    /**
    * 
    * @Title      : stopProtHandler 
    * @Description: Stop protocol handler  
    * @Param      : @param connector 
    * @Return     : void
    * @Throws     :
     */
    private void stopProtHandler(Connector connector)
    {
        if (null == connector)
        {
            return;
        }
        try
        {
            connector.getProtocolHandler().stop();
            connector.getProtocolHandler().destroy();
        }
        catch(Exception e)
        {
            log.error("Cannot pause connector: ", e);
        }
    }
    
    /**
    * 
    * @Title      : stopSilently 
    * @Description: Stop Tomcat silently, ignore exception
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void stopSilently()
    {
        try
        {
            this.tomcat.stop();
        }
        catch(LifecycleException e)
        {
            // Ignore
        }
    }
    
    /**
    * 
    * @Title      : init 
    * @Description: Initialize Tomcat container 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    private void init()
    {
        log.info("Tomcat initialized with port(s): " + this.getPortsDescr(false));
        synchronized (this.monitor)
        {
            this.setEngineName();
            try
            {
                // Remove service connectors
                rmSrvConnectors();

                // Start the server
                this.tomcat.start();

                Context ctx = this.findContext();

                try
                {
                    ContextBindings.bindClassLoader(ctx,
                                    this.getNamingToken(ctx),
                                    this.getClass().getClassLoader());
                }
                catch(NamingException e)
                {
                    // Naming is not enabled. Continue
                }

                // Create a blocking non-daemon to stop immediate shutdown
                this.startAwaitThd();
            }
            catch(Exception e)
            {
                counter.decrementAndGet();
                throw new TomcatContainerException("Unable to start Tomcat", e);
            }
        }
    }

    /**
    * 
    * @Title      : start 
    * @Description: Start Tomcat container 
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    public void start()
    {
        synchronized (this.monitor)
        {
            if (this.started)
            {
                return;
            }
            try
            {
                this.addPrevConnectors();
                Connector connector = this.tomcat.getConnector();
                if (null != connector)
                {
                    this.startContainers();
                }
                
                // Check failure exception for containers
                this.checkContainersState();

                // Check failure exception for connectors
                this.checkConnectorsState();

                this.started = true;
                log.info("Tomcat started on port(s): " + getPortsDescr(true));
            }
            catch(TomcatConnectorException e)
            {
                this.stopSilently();
                throw e;
            }
            catch(Exception e)
            {
                throw new TomcatContainerException("Unable to start Tomcat servlet container", e);
            } 
            finally
            {
                Context ctx = this.findContext();
                ContextBindings.unbindClassLoader(ctx, 
                                                  getNamingToken(ctx),
                                                  getClass().getClassLoader());
            }
        }
    }

    /**
    * 
    * @Title      : stop 
    * @Description: Stop Tomcat container  
    * @Param      :  
    * @Return     : void
    * @Throws     :
     */
    public void stop()
    {
        synchronized (this.monitor)
        {
            boolean wasStarted = this.started;
            try
            {
                this.started = false;
                try
                {
                    this.stopProtHandler(this.tomcat.getConnector());
                    this.tomcat.stop();
                    this.tomcat.destroy();
                }
                catch(LifecycleException e)
                {
                    // swallow and continue
                }
            }
            catch(Exception e)
            {
                throw new TomcatContainerException("Unable to stop Tomcat", e);
            } 
            finally
            {
                if (wasStarted)
                {
                    counter.decrementAndGet();
                }
            }
        }
    }
    
    /**
    * 
    * @Title      : getPort 
    * @Description: Return the port this server is listening on. 
    * @Param      : @return the port (or -1 if none)
    * @Return     : int
    * @Throws     :
     */
    public int getPort()
    {
        Connector connector = this.tomcat.getConnector();
        if (null != connector)
        {
            return connector.getLocalPort();
        }
        return 0;
    }

    /**
    * 
    * @Title      : getTomcat 
    * @Description: Returns access to the underlying Tomcat server 
    * @Param      : @return the Tomcat server
    * @Return     : Tomcat
    * @Throws     :
     */
    public Tomcat getTomcat()
    {
        return this.tomcat;
    }
    
    /**
    * 
    * @Title      : getSrvConnectors 
    * @Description: Get service connectors 
    * @Param      : @return 
    * @Return     : Map<Service,Connector[]>
    * @Throws     :
     */
    Map<Service, Connector[]> getSrvConnectors()
    {
        return this.srvConnectors;
    }
}
